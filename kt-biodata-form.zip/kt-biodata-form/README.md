# KT Global School — Online Interview Biodata Form

A mobile-friendly online version of the Interview Biodata Form. A candidate
fills it on their phone, it's saved automatically to this GitHub repository,
and HR opens `admin.html` to review, search, and **print** each submission
in the original form layout to hand to the interviewer.

- `index.html` — the form candidates fill on their phone
- `admin.html` — the HR view: list of submissions + a print button per candidate
- `config.js` — the only file you need to edit (repo name, token, school details)
- `submissions/` — each submission is saved here as one JSON file
- `style.css`, `app.js`, `admin.js` — supporting code, no edits needed

---

## 1. Put this on GitHub

1. Create a **new GitHub repository**, e.g. `kt-biodata-form`.
   - See the Security note below before deciding public vs. private.
2. Upload all the files in this folder to that repository (drag-and-drop
   on github.com works fine, or `git push`).
3. Go to **Settings → Pages** in the repo, and under "Build and deployment"
   choose **Deploy from a branch**, branch `main`, folder `/ (root)`. Save.
4. GitHub will give you a URL like:
   `https://YOUR-USERNAME.github.io/kt-biodata-form/`
   - The candidate form is at that URL (`index.html`).
   - The HR view is at `.../admin.html`.

## 2. Create a GitHub Personal Access Token

This token lets the form save each submission as a file in your repo.

1. On GitHub: **Settings (your profile) → Developer settings → Personal
   access tokens → Fine-grained tokens → Generate new token**.
2. **Repository access:** choose "Only select repositories" → pick your
   `kt-biodata-form` repo only.
3. **Permissions:** under "Repository permissions" set **Contents: Read
   and write**. Leave everything else as "No access".
4. Generate the token and copy it (it's shown only once).

## 3. Edit `config.js`

Open `config.js` in this repo and fill in:

```js
GITHUB_OWNER: "your-github-username",
GITHUB_REPO: "kt-biodata-form",
GITHUB_BRANCH: "main",
GITHUB_TOKEN: "the token you copied",
```

Also update `SCHOOL_NAME`, `SCHOOL_ADDRESS`, `SCHOOL_PHONE`, `SCHOOL_EMAIL`
if needed. Save and push this change — GitHub Pages updates automatically
within a minute or two.

## 3b. Add your school logo

Drop your logo file into the `assets` folder and name it exactly
`logo.png`, then push it to GitHub. It will automatically appear on the
candidate form, the HR admin console, and the printed biodata sheet — no
code changes needed. Until you add it, the pages show a plain "KT"
monogram as a safe fallback. See `assets/PUT_LOGO_HERE.txt` for size
recommendations.

## 4. Try it

- Open `index.html` on your phone (or the GitHub Pages URL) and submit a
  test entry.
- Open `admin.html` — you should see the test submission. Tap **View /
  Print** and then **Print / Save PDF**.

## 5. Day-to-day use

- Send candidates the `index.html` (Pages) link — e.g. via WhatsApp or a QR
  code at the front desk. They fill it on their own phone.
- HR opens `admin.html` any time to see new submissions, search by name or
  mobile number, and print the ones that are ready to hand to an interviewer.
- Every submission is also just a plain JSON file inside `submissions/` in
  the repo, so nothing is ever lost, and you have a full history in GitHub.

---

## Security — please read before going live

`config.js` (including the token) is downloaded by every phone that opens
the form, because it's a static site. That's fine for a **private** repo
used only by candidates you've personally sent the link to, but it does
mean anyone with the link and a little technical knowledge could read the
token from their browser. Since the token above can *only* write to this
one repository, the worst case is someone adding junk files to
`submissions/` — it cannot touch your other repos or account.

To reduce risk further, pick one of these:

1. **Keep the repository private.** Private repos support GitHub Pages on
   paid GitHub plans (Pro / Team / Enterprise, or GitHub Education). This
   is the simplest fix — the site (and the token in it) is then only
   reachable by people you've explicitly given access to.
2. **Rotate the token periodically** (e.g. every admission season) from
   the same Developer settings page.
3. **For a fully public form** (e.g. linked from your public website),
   don't put a token in the browser at all — instead route submissions
   through a small serverless function (a free Cloudflare Worker or
   Vercel/Netlify function) that holds the token server-side and forwards
   the write to GitHub. This is more setup but keeps the token off every
   visitor's phone. Ask your developer, or ask Claude, for help wiring
   this up if you'd like to move to this option later.

## Customising the form

- Dropdown options (Category, Religion, Gender, etc.) are defined directly
  in `index.html` — search for `<select` and edit the `<option>` lines.
- Required fields have the `required` attribute in `index.html` — add or
  remove it on any field to change what's mandatory.
- Educational-qualification rows and the achievements list are defined at
  the top of `app.js` (`EDU_LEVELS` and `ACHIEVEMENTS` arrays) if you need
  to add or rename a row.
