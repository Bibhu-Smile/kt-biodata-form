/* ===================================================================
   KT GLOBAL SCHOOL — Interview Biodata Form
   CONFIGURATION
   Edit the values below after you fork/clone this into your own
   GitHub repository. See README.md for full setup steps.
=================================================================== */

const CONFIG = {
  // Your GitHub username or organisation
  GITHUB_OWNER: "your-github-username",

  // The repository name where this site lives / submissions are saved
  GITHUB_REPO: "kt-biodata-form",

  // Branch to commit submissions to
  GITHUB_BRANCH: "main",

  // Folder (inside the repo) where each submission JSON file is stored
  SUBMISSIONS_PATH: "submissions",

  // A GitHub Personal Access Token (fine-grained), scoped ONLY to this
  // repository, with "Contents: Read and write" permission.
  // ⚠️ SECURITY NOTE: this file is public if your repo/Pages site is
  // public, which means this token is public too. Read the "Security"
  // section in README.md before going live — the safe options are:
  //   1) Keep this repository PRIVATE (GitHub Pages supports private
  //      repos on paid plans), or
  //   2) Route submissions through a small serverless proxy (Cloudflare
  //      Worker / Vercel function) instead of calling the GitHub API
  //      directly from the browser, so the token never ships to
  //      candidates' phones.
  // A token pasted here is visible to every candidate who opens the
  // form. Use a token that can ONLY write to this one repo.
  GITHUB_TOKEN: "PASTE_YOUR_FINE_GRAINED_TOKEN_HERE",

  SCHOOL_NAME: "KT GLOBAL SCHOOL",
  SCHOOL_ADDRESS: "Plot No. F/12, IID Centre, Barunei, Khordha, Odisha - 752057",
  SCHOOL_PHONE: "+91 90901 11177",
  SCHOOL_EMAIL: "info@ktglobalschool.org",
};
