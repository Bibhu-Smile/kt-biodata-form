/* KT Global School — Interview Biodata Form logic */

/* ---------- Fixed Education rows ---------- */
const EDU_LEVELS = [
  { key: "secondary", label: "Secondary (10th)" },
  { key: "seniorSecondary", label: "Senior Secondary (12th)" },
  { key: "graduation", label: "Graduation (mention Hons. subject)" },
  { key: "postGraduation", label: "Post Graduation" },
  { key: "bed", label: "B.Ed., CT, NTT, B.P.Ed." },
  { key: "tet", label: "OTET / CTET / OSTET" },
];

const eduBody = document.getElementById("eduTableBody");
EDU_LEVELS.forEach(lvl => {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>${lvl.label}</td>
    <td><input type="number" data-edu="${lvl.key}" data-field="year" min="1970" max="2026" placeholder="YYYY"></td>
    <td><input type="text" data-edu="${lvl.key}" data-field="subjects" placeholder="Subjects"></td>
    <td><input type="text" data-edu="${lvl.key}" data-field="board" placeholder="Board / University"></td>
    <td><input type="text" data-edu="${lvl.key}" data-field="marks" placeholder="% / CGPA"></td>
  `;
  eduBody.appendChild(tr);
});

/* ---------- Fixed Achievements rows ---------- */
const ACHIEVEMENTS = ["Literary Activity", "Art & Craft", "Sports", "Cultural Activity, Music & Dance"];
const achieveBody = document.getElementById("achieveBody");
ACHIEVEMENTS.forEach((label, i) => {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>${label}</td>
    <td>
      <select data-achieve="${i}" data-field="has">
        <option value="No">No</option>
        <option value="Yes">Yes</option>
      </select>
    </td>
    <td><input type="text" data-achieve="${i}" data-field="details" placeholder="e.g. State-level, 2024"></td>
  `;
  achieveBody.appendChild(tr);
});

/* ---------- Address: same as permanent ---------- */
const permanentAddress = document.getElementById("permanentAddress");
const communicationAddress = document.getElementById("communicationAddress");
const sameAddress = document.getElementById("sameAddress");
sameAddress.addEventListener("change", () => {
  if (sameAddress.checked) {
    communicationAddress.value = permanentAddress.value;
    communicationAddress.disabled = true;
  } else {
    communicationAddress.disabled = false;
  }
});

/* ---------- Age auto-calc from DOB (editable after) ---------- */
document.getElementById("dob").addEventListener("change", (e) => {
  const dob = new Date(e.target.value);
  const ref = new Date("2026-01-01");
  if (!isNaN(dob)) {
    let age = ref.getFullYear() - dob.getFullYear();
    const m = ref.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && ref.getDate() < dob.getDate())) age--;
    document.getElementById("age").value = age;
  }
});

/* ---------- Date field ---------- */
document.getElementById("formDate").value = new Date().toLocaleDateString("en-IN", {
  day: "2-digit", month: "short", year: "numeric"
});

/* ---------- Photo upload ---------- */
const photoInput = document.getElementById("photoInput");
const photoPreview = document.getElementById("photoPreview");
const photoUploadText = document.getElementById("photoUploadText");
const photoUploadLabel = document.getElementById("photoUploadLabel");
let photoDataUrl = "";

photoUploadLabel.addEventListener("click", (e) => {
  if (e.target !== photoInput) photoInput.click();
});

photoInput.addEventListener("change", () => {
  const file = photoInput.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = new Image();
    img.onload = () => {
      // Resize/compress so the JSON stays a reasonable size
      const maxDim = 500;
      let { width, height } = img;
      if (width > height && width > maxDim) { height *= maxDim / width; width = maxDim; }
      else if (height > maxDim) { width *= maxDim / height; height = maxDim; }
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = height;
      canvas.getContext("2d").drawImage(img, 0, 0, width, height);
      photoDataUrl = canvas.toDataURL("image/jpeg", 0.75);
      photoPreview.src = photoDataUrl;
      photoPreview.style.display = "block";
      photoUploadText.style.display = "none";
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
});

/* ---------- Signature pad ---------- */
const canvas = document.getElementById("sigPad");
const ctx = canvas.getContext("2d");
let drawing = false, hasSignature = false;

function resizeCanvas() {
  const ratio = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * ratio;
  canvas.height = rect.height * ratio;
  ctx.scale(ratio, ratio);
  ctx.lineWidth = 2.2;
  ctx.lineCap = "round";
  ctx.strokeStyle = "#152a4d";
}
window.addEventListener("resize", () => {
  const data = hasSignature ? canvas.toDataURL() : null;
  resizeCanvas();
  if (data) { const img = new Image(); img.onload = () => ctx.drawImage(img, 0, 0, canvas.getBoundingClientRect().width, canvas.getBoundingClientRect().height); img.src = data; }
});
resizeCanvas();

function getPos(e) {
  const rect = canvas.getBoundingClientRect();
  const t = e.touches ? e.touches[0] : e;
  return { x: t.clientX - rect.left, y: t.clientY - rect.top };
}
function start(e) { drawing = true; hasSignature = true; const p = getPos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); document.getElementById("sigStatus").textContent = "Signature captured"; e.preventDefault(); }
function move(e) { if (!drawing) return; const p = getPos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); e.preventDefault(); }
function end() { drawing = false; }

canvas.addEventListener("mousedown", start);
canvas.addEventListener("mousemove", move);
window.addEventListener("mouseup", end);
canvas.addEventListener("touchstart", start, { passive: false });
canvas.addEventListener("touchmove", move, { passive: false });
canvas.addEventListener("touchend", end);

document.getElementById("clearSig").onclick = () => {
  const rect = canvas.getBoundingClientRect();
  ctx.clearRect(0, 0, rect.width, rect.height);
  hasSignature = false;
  document.getElementById("sigStatus").textContent = "Sign above";
};

/* ---------- Collect form data ---------- */
function collectData() {
  const val = id => document.getElementById(id).value.trim();

  const education = {};
  EDU_LEVELS.forEach(lvl => {
    education[lvl.key] = {
      label: lvl.label,
      year: document.querySelector(`[data-edu="${lvl.key}"][data-field="year"]`).value,
      subjects: document.querySelector(`[data-edu="${lvl.key}"][data-field="subjects"]`).value,
      board: document.querySelector(`[data-edu="${lvl.key}"][data-field="board"]`).value,
      marks: document.querySelector(`[data-edu="${lvl.key}"][data-field="marks"]`).value,
    };
  });

  const achievements = ACHIEVEMENTS.map((label, i) => ({
    label,
    has: document.querySelector(`[data-achieve="${i}"][data-field="has"]`).value,
    details: document.querySelector(`[data-achieve="${i}"][data-field="details"]`).value,
  }));

  const workExperience = [1, 2, 3].map(n => ({
    institution: val(`exp${n}Inst`),
    designation: val(`exp${n}Desig`),
    duration: val(`exp${n}Duration`),
    salary: val(`exp${n}Salary`),
  })).filter(r => r.institution || r.designation || r.duration || r.salary);

  return {
    submittedAt: new Date().toISOString(),
    status: "New",
    postApplied: val("postApplied"),
    applicantName: val("applicantName").toUpperCase(),
    fatherHusbandName: val("fatherHusbandName").toUpperCase(),
    dob: val("dob"),
    age: val("age"),
    bloodGroup: val("bloodGroup"),
    category: val("category"),
    religion: val("religion"),
    nationality: val("nationality"),
    gender: val("gender"),
    maritalStatus: val("maritalStatus"),
    hobbies: val("hobbies"),
    permanentAddress: val("permanentAddress"),
    communicationAddress: sameAddress.checked ? val("permanentAddress") : val("communicationAddress"),
    mobile1: val("mobile1"),
    email: val("email"),
    aadhaar: val("aadhaar"),
    pan: val("pan").toUpperCase(),
    education,
    extraQual: val("extraQual"),
    workExperience,
    achievements,
    currentSalary: val("currentSalary"),
    minSalary: val("minSalary"),
    joiningTime: val("joiningTime"),
    transport: val("transport"),
    photo: photoDataUrl,
    place: val("place"),
    formDate: val("formDate"),
    signature: hasSignature ? canvas.toDataURL("image/png") : "",
  };
}

/* ---------- GitHub save ---------- */
async function saveToGitHub(data) {
  const safeName = data.applicantName.replace(/[^A-Z0-9]+/gi, "-").toUpperCase() || "APPLICANT";
  const filename = `${Date.now()}-${safeName}.json`;
  const path = `${CONFIG.SUBMISSIONS_PATH}/${filename}`;
  const url = `https://api.github.com/repos/${CONFIG.GITHUB_OWNER}/${CONFIG.GITHUB_REPO}/contents/${path}`;

  const content = btoa(unescape(encodeURIComponent(JSON.stringify(data, null, 2))));

  const res = await fetch(url, {
    method: "PUT",
    headers: {
      "Authorization": `Bearer ${CONFIG.GITHUB_TOKEN}`,
      "Accept": "application/vnd.github+json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message: `New biodata submission: ${data.applicantName}`,
      content,
      branch: CONFIG.GITHUB_BRANCH,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `GitHub API error (${res.status})`);
  }
  return filename;
}

/* ---------- Submit handler ---------- */
const form = document.getElementById("biodataForm");
const statusMsg = document.getElementById("statusMsg");
const submitBtn = document.getElementById("submitBtn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  statusMsg.textContent = "";
  statusMsg.className = "status-msg";

  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  if (!hasSignature) {
    statusMsg.textContent = "Please add your signature before submitting.";
    statusMsg.className = "status-msg error";
    document.getElementById("sigPad").scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }
  if (!document.getElementById("declaration").checked) {
    statusMsg.textContent = "Please agree to the declaration.";
    statusMsg.className = "status-msg error";
    return;
  }

  const data = collectData();
  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting…";

  try {
    if (!CONFIG.GITHUB_TOKEN || CONFIG.GITHUB_TOKEN.includes("PASTE_YOUR")) {
      throw new Error("NOT_CONFIGURED");
    }
    await saveToGitHub(data);
    document.getElementById("formStage").style.display = "none";
    document.getElementById("successStage").style.display = "block";
    window.scrollTo(0, 0);
  } catch (err) {
    if (err.message === "NOT_CONFIGURED") {
      statusMsg.innerHTML = "Online saving isn't set up yet on this site. Your response has been downloaded as a file instead — please hand it to HR.";
    } else {
      statusMsg.innerHTML = "Could not save online (" + err.message + "). Your response has been downloaded as a file instead — please hand it to HR.";
    }
    statusMsg.className = "status-msg error";
    downloadJSON(data);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "📩 Submit Application";
  }
});

function downloadJSON(data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${data.applicantName || "applicant"}-biodata.json`;
  a.click();
}
