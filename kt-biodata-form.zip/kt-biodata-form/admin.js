/* KT Global School — HR Admin logic */

document.getElementById("schoolName").textContent = CONFIG.SCHOOL_NAME;

const listView = document.getElementById("listView");
const printView = document.getElementById("printView");
const subList = document.getElementById("subList");
const loadStatus = document.getElementById("loadStatus");
const emptyNote = document.getElementById("emptyNote");
const searchBox = document.getElementById("searchBox");

let allSubs = [];

function authHeaders() {
  const h = { "Accept": "application/vnd.github+json" };
  if (CONFIG.GITHUB_TOKEN && !CONFIG.GITHUB_TOKEN.includes("PASTE_YOUR")) {
    h["Authorization"] = `Bearer ${CONFIG.GITHUB_TOKEN}`;
  }
  return h;
}

async function loadSubmissions() {
  loadStatus.textContent = "Loading submissions…";
  subList.innerHTML = "";
  emptyNote.style.display = "none";

  const listUrl = `https://api.github.com/repos/${CONFIG.GITHUB_OWNER}/${CONFIG.GITHUB_REPO}/contents/${CONFIG.SUBMISSIONS_PATH}?ref=${CONFIG.GITHUB_BRANCH}`;

  try {
    const res = await fetch(listUrl, { headers: authHeaders() });
    if (res.status === 404) {
      loadStatus.textContent = "";
      emptyNote.style.display = "block";
      return;
    }
    if (!res.ok) throw new Error(`GitHub API error (${res.status})`);
    const files = await res.json();
    const jsonFiles = files.filter(f => f.name.endsWith(".json"));

    if (jsonFiles.length === 0) {
      loadStatus.textContent = "";
      emptyNote.style.display = "block";
      return;
    }

    loadStatus.textContent = `Loading ${jsonFiles.length} submission(s)…`;

    const results = await Promise.all(jsonFiles.map(async f => {
      const r = await fetch(f.download_url);
      const data = await r.json();
      data._filename = f.name;
      return data;
    }));

    results.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));
    allSubs = results;
    loadStatus.textContent = `${results.length} submission(s) loaded.`;
    renderList(results);
  } catch (err) {
    loadStatus.textContent = "Could not load submissions: " + err.message +
      ". Check that config.js has the correct GITHUB_OWNER / GITHUB_REPO / GITHUB_TOKEN.";
  }
}

function renderList(items) {
  subList.innerHTML = "";
  if (items.length === 0) {
    emptyNote.style.display = "block";
    return;
  }
  emptyNote.style.display = "none";
  items.forEach(data => {
    const li = document.createElement("li");
    li.className = "sub-item";
    const when = data.submittedAt ? new Date(data.submittedAt).toLocaleString("en-IN") : "";
    li.innerHTML = `
      <div class="meta">
        <strong>${escapeHtml(data.applicantName || "Unnamed")}</strong>
        <span>${escapeHtml(data.mobile1 || "")} &middot; ${escapeHtml(when)}</span>
      </div>
      <div class="actions">
        <button class="secondary" data-act="view">View / Print</button>
      </div>
    `;
    li.querySelector('[data-act="view"]').onclick = () => showPrintView(data);
    subList.appendChild(li);
  });
}

searchBox.addEventListener("input", () => {
  const q = searchBox.value.trim().toLowerCase();
  const filtered = allSubs.filter(d =>
    (d.applicantName || "").toLowerCase().includes(q) ||
    (d.mobile1 || "").includes(q)
  );
  renderList(filtered);
});

document.getElementById("refreshBtn").onclick = loadSubmissions;

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------- Printable sheet ---------- */
function showPrintView(data) {
  listView.style.display = "none";
  printView.style.display = "block";
  window.scrollTo(0, 0);

  const eduRows = Object.values(data.education || {}).map(e => `
    <tr><td>${escapeHtml(e.label)}</td><td>${escapeHtml(e.year)}</td><td>${escapeHtml(e.subjects)}</td><td>${escapeHtml(e.board)}</td><td>${escapeHtml(e.marks)}</td></tr>
  `).join("");

  const extraQualRows = (data.extraQual || []).map(r => `
    <tr><td>${escapeHtml(r.qualification)}</td><td>${escapeHtml(r.specialization)}</td><td>${escapeHtml(r.year)}</td><td>${escapeHtml(r.university)}</td><td>${escapeHtml(r.marks)}</td><td>${escapeHtml(r.other)}</td></tr>
  `).join("") || `<tr><td colspan="6" style="text-align:center;color:#999;">None provided</td></tr>`;

  const workRows = (data.workExperience || []).map(r => `
    <tr><td>${escapeHtml(r.institution)}</td><td>${escapeHtml(r.designation)}</td><td>${escapeHtml(r.from)}</td><td>${escapeHtml(r.to)}</td><td>${escapeHtml(r.subject)}</td><td>${escapeHtml(r.salary)}</td></tr>
  `).join("") || `<tr><td colspan="6" style="text-align:center;color:#999;">None provided</td></tr>`;

  const achieveRows = (data.achievements || []).map(a => `
    <tr><td>${escapeHtml(a.label)}</td><td>${escapeHtml(a.has)}</td><td>${escapeHtml(a.details)}</td></tr>
  `).join("");

  document.getElementById("printSheet").innerHTML = `
    <div class="ps-letterhead">
      <img src="assets/logo.png" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'crest',textContent:'KT'}))">
      <div>
        <h1>${escapeHtml(CONFIG.SCHOOL_NAME)}</h1>
        <div class="psub" style="margin-bottom:0;">${escapeHtml(CONFIG.SCHOOL_ADDRESS)} &middot; ${escapeHtml(CONFIG.SCHOOL_PHONE)} &middot; ${escapeHtml(CONFIG.SCHOOL_EMAIL)}</div>
      </div>
    </div>
    <p style="text-align:center;margin-top:10px;"><span class="status-badge">INTERVIEW BIODATA FORM</span></p>

    <h3>General Information</h3>
    <table>
      <tr><td class="ps-label">Name of Applicant</td><td>${escapeHtml(data.applicantName)}</td><td class="ps-label">Father's / Husband's Name</td><td>${escapeHtml(data.fatherHusbandName)}</td></tr>
      <tr><td class="ps-label">Date of Birth</td><td>${escapeHtml(data.dob)}</td><td class="ps-label">Age (as on 1 Jan 2026)</td><td>${escapeHtml(data.age)}</td></tr>
      <tr><td class="ps-label">Category</td><td>${escapeHtml(data.category)}</td><td class="ps-label">Religion</td><td>${escapeHtml(data.religion)}</td></tr>
      <tr><td class="ps-label">Nationality</td><td>${escapeHtml(data.nationality)}</td><td class="ps-label">Gender</td><td>${escapeHtml(data.gender)}</td></tr>
      <tr><td class="ps-label">Marital Status</td><td>${escapeHtml(data.maritalStatus)}</td><td class="ps-label">Hobbies</td><td>${escapeHtml(data.hobbies)}</td></tr>
      <tr><td class="ps-label">Mobile (Primary)</td><td>${escapeHtml(data.mobile1)}</td><td class="ps-label">Mobile (Alternate)</td><td>${escapeHtml(data.mobile2)}</td></tr>
      <tr><td class="ps-label">E-mail</td><td colspan="3">${escapeHtml(data.email)}</td></tr>
      <tr><td class="ps-label">Aadhaar No.</td><td>${escapeHtml(data.aadhaar)}</td><td class="ps-label">PAN No.</td><td>${escapeHtml(data.pan)}</td></tr>
      <tr><td class="ps-label">Permanent Address</td><td colspan="3">${escapeHtml(data.permanentAddress)}</td></tr>
      <tr><td class="ps-label">Communication Address</td><td colspan="3">${escapeHtml(data.communicationAddress)}</td></tr>
    </table>

    <h3>Educational Qualifications</h3>
    <table>
      <tr><th>Qualification</th><th>Year</th><th>Subjects</th><th>Board / University</th><th>Marks %/CGPA</th></tr>
      ${eduRows}
    </table>

    <h3>Extra Qualification</h3>
    <table>
      <tr><th>Qualification</th><th>Specialization</th><th>Year</th><th>University</th><th>Marks</th><th>Other Info</th></tr>
      ${extraQualRows}
    </table>

    <h3>Work Experience</h3>
    <table>
      <tr><th>Institution</th><th>Designation</th><th>From</th><th>To</th><th>Subject/Class</th><th>Gross Salary</th></tr>
      ${workRows}
    </table>
    <table>
      <tr><td class="ps-label">Teaching Exp. (yrs)</td><td>${escapeHtml(data.expTeaching)}</td><td class="ps-label">Administrative Exp. (yrs)</td><td>${escapeHtml(data.expAdmin)}</td><td class="ps-label">Other Exp. (yrs)</td><td>${escapeHtml(data.expOther)}</td></tr>
    </table>

    <h3>Achievements</h3>
    <table>
      <tr><th>Particular</th><th>Attached?</th><th>Details</th></tr>
      ${achieveRows}
    </table>

    <h3>Compensation & Availability</h3>
    <table>
      <tr><td class="ps-label">Minimum Salary Expected</td><td>Rs. ${escapeHtml(data.minSalary)} / month</td></tr>
      <tr><td class="ps-label">Time Needed to Join</td><td>${escapeHtml(data.joiningTime)}</td></tr>
      <tr><td class="ps-label">Post Type Preference</td><td>${escapeHtml(data.postType)}</td></tr>
    </table>

    <h3>Declaration</h3>
    <table>
      <tr><td class="ps-label">Place</td><td>${escapeHtml(data.place)}</td><td class="ps-label">Date</td><td>${escapeHtml(data.formDate)}</td></tr>
      <tr><td class="ps-label">Signature</td><td colspan="3">${data.signature ? `<img class="sig-img" src="${data.signature}">` : "(not captured)"}</td></tr>
    </table>

    <p style="font-size:.72rem;color:#888;text-align:right;margin-top:10px;">Submitted online: ${data.submittedAt ? new Date(data.submittedAt).toLocaleString("en-IN") : ""} &middot; File: ${escapeHtml(data._filename)}</p>
  `;
}

function backToList() {
  printView.style.display = "none";
  listView.style.display = "block";
}

loadSubmissions();
